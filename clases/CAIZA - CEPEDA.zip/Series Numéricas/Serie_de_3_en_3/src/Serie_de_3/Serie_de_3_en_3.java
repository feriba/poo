package Serie_de_3;

public class Serie_de_3_en_3 {

    public int numero = 3;

    public void numeroPrincipal() {

        System.out.println(this.numero);
    }

    public void Resulado() {
        int m = 0;
        for (m = 6; m <= 50; m += 3) {
            System.out.println(m);

        }

    }

}
