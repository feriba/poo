package Principal;

import Serie_de_3.Serie_de_3_en_3;

public class Principal {

    public static void main(String[] arg) {
        Serie_de_3_en_3 resultado = new Serie_de_3_en_3();
        resultado.numeroPrincipal();
        resultado.Resulado();

    }

}
