package contenedorDeber;

public class Contenedor {

    public int num = 7;
    public int num1 = 9;
    public int suma = num + 2;

    public void Serie() {
        System.out.println(num);
        System.out.println(num1);
        int i = 0;
        while (i < 15) {
            int secuencia = num + suma;
            System.out.println(secuencia);
            num = secuencia;
            num1 = num;
            i++;
        }
    }
}
