package deber;

import contenedorDeber.Contenedor;

/**
 *
 * @author chris
 */
public class Deber {

    public static void main(String[] args) {
        Contenedor Serie = new Contenedor();
        Serie.Serie();
    }
}
