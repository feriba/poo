/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Operaciones;

/**
 *
 * @author edu
 */
public class Desarrollo {

    public int numinicial = 0, numfinal;
    public int patron = 1;
    public int incremento = 1;

    public void proceso() {
        System.out.println(numinicial);

        int i;
        for (i = 0; i < 9; i++) {
            numfinal = numinicial + patron;
            
            incremento++;
            patron = (int) Math.pow(incremento, 2);

            System.out.println(numfinal);

            numinicial = numfinal;

        }
    }

}
