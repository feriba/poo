/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import contenedor.Calculo;

/**
 *
 * @author Usuario
 */
public class Principal {
    public static void main (String [] args ){
        Calculo serie = new Calculo();
        serie.imprimir();
        serie.resolver();
       
    }
}
