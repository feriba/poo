/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package contenedor;

/**
 *
 * @author Usuario
 */
public class Calculo {
    public int a = 1;
    public int b = 3;
     public void imprimir(){
         System.out.println(a);
         System.out.println(b);   
     }
    
     public void resolver(){
         int i =0;
         while(i < 8 ){
           int siguienteNumero = b * 2;
           this.resultado(siguienteNumero);
           b= siguienteNumero;
             i++;
         }
     }
     public void resultado(int siguienteNumero){
          System.out.println(siguienteNumero);
     }
}
