/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Serie;

/**
 *
 * @author Daysy
 * 16-05-2021
 */
public class Serie {

    /*Propiedad*/
    public int numero1 = 1;

    /*Método adicionar*/
    public void adicionar() {
        System.out.println(numero1);
        int d = 0;
        while (d < 14) {
            int auxiliar = numero1 + 8;
            numero1 = auxiliar;
            System.out.println(auxiliar);
            d++;
        }
    }
}
