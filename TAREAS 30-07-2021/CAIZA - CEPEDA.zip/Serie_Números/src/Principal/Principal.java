/*
 * Empresa desarrollo
 * SOFTWARE
 */
package Principal;

import Serie.Serie;

/**
 *
 * @author John Peña
 * @date mayo 19 2021
 */
public class Principal {
    public static void main(String [ ] args){
        Serie serie = new Serie ();
        serie.incremento();
    }
}
