/*
 * Empresa desarrollo
 * SOFTWARE
 */
package Serie;

/**
 *
 * @author John Peña
 * @date mayo 19 2021
 */
public class Serie {

    public int número1 = 1;
    public int número2 = 10;

    public void incremento() {
        System.out.println(número1);
        System.out.println(número2);
        int i = 0;
        while (i < 19) {

            número1 += 1;
            número2 += 10;
            System.out.println(número1);
            System.out.println(número2);
            i++;
        }
    }
}
