
public class SerieNumerica {

    public int nro1 = 1;

    public void multiplicar() {
        int i = 0;

        while (i < 9) {

            int aux = nro1 * 2;
            nro1 = aux;
            System.out.println(aux);
        

            i++;
        }

    }

    
}
