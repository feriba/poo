
public class PruebaSerie {

    public static void main(String[] args) {
        SerieNumerica serie1 = new SerieNumerica();
        serie1.multiplicar();

    }

}
